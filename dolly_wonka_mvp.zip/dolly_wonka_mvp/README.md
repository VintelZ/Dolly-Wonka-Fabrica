# Dolly Wonka INC. — MVP

## Estrutura
- `frontend/`: site estático para GitHub Pages.
- `backend/`: API Node.js + SQLite + login OAuth2 do Discord.

## Antes de publicar
1. Crie uma aplicação no Discord Developer Portal.
2. Em OAuth2, adicione como redirect URI:
   `https://SEU-BACKEND.example.com/auth/discord/callback`
3. No backend, copie `.env.example` para `.env` e preencha as credenciais.
4. Publique o backend em um host Node.js que ofereça armazenamento persistente para SQLite.
5. No `frontend/app.js`, troque `API` pela URL pública do backend.
6. Publique a pasta `frontend` no GitHub Pages.

## Importante
Nunca coloque `DISCORD_CLIENT_SECRET` no frontend/GitHub.
SQLite serve para o MVP; para produção/muitos jogadores, troque por PostgreSQL/Supabase.
