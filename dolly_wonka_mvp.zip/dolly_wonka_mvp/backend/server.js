require("dotenv").config();
const express=require("express"),session=require("express-session"),cors=require("cors"),Database=require("better-sqlite3");
const app=express(),db=new Database("dolly.db");
app.use(express.json());app.use(cors({origin:process.env.FRONTEND_URL,credentials:true}));
app.use(session({secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"none",secure:true,maxAge:86400000}}));
db.exec(`CREATE TABLE IF NOT EXISTS workers(discord_id TEXT PRIMARY KEY, username TEXT, role TEXT DEFAULT 'Operador', coins INTEGER DEFAULT 0, xp INTEGER DEFAULT 0, efficiency INTEGER DEFAULT 100);
CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT,discord_id TEXT,product TEXT,coins INTEGER,xp INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
const products=["Chiclete de Morango","Pirulito de Uva","Bala de Cola"];
const steps=[
{title:"Dosagem",question:"A máquina pede uma medição precisa. Qual é a prioridade?",options:["Ignorar a calibração","Conferir a medida antes de produzir","Adicionar o dobro"],answer:1},
{title:"Cozimento",question:"A mistura chegou ao ponto indicado. O que fazer?",options:["Manter o processo no ponto indicado","Aumentar sem motivo","Parar e jogar fora"],answer:0},
{title:"Qualidade",question:"Um lote apresenta pequena diferença de textura. Qual decisão?",options:["Liberar sem conferir","Esconder o problema","Separar e inspecionar o lote"],answer:2},
{title:"Embalagem",question:"A embalagem está alinhada e lacrada. Próximo passo?",options:["Enviar para expedição","Abrir novamente","Misturar com material sem identificação"],answer:0}
];
function worker(){if(!req.session.user)return null;return db.prepare("SELECT * FROM workers WHERE discord_id=?").get(req.session.user.id)}
app.get("/api/me",(req,res)=>{const w=worker();if(!w)return res.json({user:null});res.json({user:req.session.user,worker:w,history:db.prepare("SELECT product,coins,xp FROM history WHERE discord_id=? ORDER BY id DESC LIMIT 8").all(req.session.user.id)})});
app.get("/auth/discord",(req,res)=>{const p=new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,response_type:"code",redirect_uri:process.env.DISCORD_REDIRECT_URI,scope:"identify"});res.redirect("https://discord.com/oauth2/authorize?"+p)});
app.get("/auth/discord/callback",async(req,res)=>{try{const p=new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,client_secret:process.env.DISCORD_CLIENT_SECRET,grant_type:"authorization_code",code:req.query.code,redirect_uri:process.env.DISCORD_REDIRECT_URI});const t=await fetch("https://discord.com/api/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:p});const tok=await t.json();const u=await (await fetch("https://discord.com/api/users/@me",{headers:{Authorization:`Bearer ${tok.access_token}`}})).json();req.session.user=u;db.prepare("INSERT OR IGNORE INTO workers(discord_id,username) VALUES(?,?)").run(u.id,u.global_name||u.username);res.redirect(process.env.FRONTEND_URL)}catch(e){res.status(500).send("Falha no login Discord")}});

app.post("/api/work/start",(req,res)=>{if(!worker())return res.status(401).send("Não autenticado");const product=products[Math.floor(Math.random()*products.length)];const lot={id:Date.now(),product,steps};req.session.lot=lot;res.json({lot})});
app.post("/api/work/finish",(req,res)=>{const w=worker(),lot=req.session.lot;if(!w||!lot||lot.id!==req.body.lotId)return res.status(400).send("Turno inválido");const correct=Math.max(0,Math.min(4,Number(req.body.correct)||0));const efficiency=Math.round(correct/4*100);const coins=20+correct*15,xp=10+correct*10;db.prepare("UPDATE workers SET coins=coins+?,xp=xp+?,efficiency=? WHERE discord_id=?").run(coins,xp,efficiency,w.discord_id);db.prepare("INSERT INTO history(discord_id,product,coins,xp) VALUES(?,?,?,?)").run(w.discord_id,lot.product,coins,xp);delete req.session.lot;const nw=worker();res.json({message:`${lot.product}: ${correct}/4 etapas corretas. Pagamento: ${coins} coins e ${xp} XP.`,worker:nw,history:db.prepare("SELECT product,coins,xp FROM history WHERE discord_id=? ORDER BY id DESC LIMIT 8").all(w.discord_id)})});
app.listen(process.env.PORT||3000,()=>console.log("Dolly Wonka backend online"));
