const API = "https://SEU-BACKEND.example.com";
const $=id=>document.getElementById(id);
let state=null;
async function api(path,opts={}){const r=await fetch(API+path,{credentials:"include",...opts});if(!r.ok)throw new Error(await r.text());return r.json();}
async function boot(){try{state=await api("/api/me"); if(!state.user){$("loginBox").hidden=false;return} $("loginBox").hidden=true;$("app").hidden=false;render();}catch(e){console.error(e)}}
function render(){ $("name").textContent=state.user.global_name||state.user.username;$("role").textContent=state.worker.role;$("coins").textContent=state.worker.coins;$("xp").textContent=state.worker.xp;$("level").textContent=state.worker.level;$("eff").textContent=state.worker.efficiency+"%";$("bar").style.width=Math.min(100,state.worker.xp%100)+"%";$("history").innerHTML=state.history.length?state.history.map(x=>`<div class="historyItem">${x.product} — +${x.coins} coins / +${x.xp} XP</div>`).join(""):"Nenhum turno ainda."}
function login(){location.href=API+"/auth/discord"}
$("login").onclick=login;$("login2").onclick=login;
$("start").onclick=async()=>{const r=await api("/api/work/start",{method:"POST"});$("start").disabled=true;$("status").textContent="EM TURNO";$("lot").textContent=`Lote #${r.lot.id} — ${r.lot.product}`;play(r.lot);};
function play(lot){let i=0,correct=0;const box=$("game");function step(){if(i>=lot.steps.length){finish();return}const s=lot.steps[i];box.innerHTML=`<div class="result"><b>Etapa ${i+1}/${lot.steps.length}: ${s.title}</b><p>${s.question}</p>${s.options.map((o,n)=>`<button class="option" data-n="${n}">${o}</button>`).join("")}</div>`;box.querySelectorAll(".option").forEach(b=>b.onclick=()=>{if(+b.dataset.n===s.answer)correct++;i++;step()})}async function finish(){const r=await api("/api/work/finish",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({lotId:lot.id,correct})});box.innerHTML=`<div class="result"><b>Turno encerrado.</b><p>${r.message}</p></div>`;state.worker=r.worker;state.history=r.history;$("status").textContent="FOLGA";$("start").disabled=false;render()}step()}
boot();
